Tarball to install dus with guidus alias mkusb version 12
---------------------------------------------------------

1. Try first to install from the PPAs

ppa:mkusb/ppa
ppa:mkusb/unstable

according to this link

https://help.ubuntu.com/community/mkusb/gui#Installation

The PPAs should work with Debian and Ubuntu and some distros and re-spins
based on Debian and Ubuntu.


2. Use this tarball if it does not work to install from the PPAs

Extract the downloaded tarball 'dus.tar.gz'

 $ tar -xvzf dus.tar.gz

Change current directory to the directory created by the extraction

 $ cd dus-tmp

Run the 'dus-installer' script to install dus

 $ sudo ./dus-installer i

or

 # ./dus-installer i

If the installer wants you to install some other programs, please do so.
Otherwise there might be problems to run dus.

or to remove dus

 $ sudo ./dus-installer r

or

 # ./dus-installer r


3. Usage text

 $ ./dus-installer 
 Run with superuser privileges, as root or with sudo

 # ./dus-installer i       # install as root
 $ sudo ./dus-installer i  # install with sudo

 # ./dus-installer r       # remove as root
 $ sudo ./dus-installer r  # remove with sudo
